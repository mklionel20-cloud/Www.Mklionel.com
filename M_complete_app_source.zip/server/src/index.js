import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import db from './db.js';

const app=express();
const PORT=process.env.PORT||4000;
const JWT_SECRET=process.env.JWT_SECRET;
if(!JWT_SECRET) console.warn('WARNING: Set JWT_SECRET in server/.env before deployment.');
app.use(cors({origin:process.env.CLIENT_ORIGIN?.split(',')||true}));
app.use(express.json({limit:'1mb'}));

function auth(req,res,next){
 const h=req.headers.authorization||'';
 const token=h.startsWith('Bearer ')?h.slice(7):'';
 try{if(!token)throw new Error();req.user=jwt.verify(token,JWT_SECRET||'development-only-secret');next();}
 catch{return res.status(401).json({error:'Please sign in to continue.'});}
}
function safeUser(u){return {id:u.id,name:u.name,email:u.email};}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'M API'}));
app.post('/api/auth/register',async(req,res)=>{
 try{
  const {name,email,password}=req.body||{};
  if(!name?.trim()||!email?.trim()||!password||password.length<8)return res.status(400).json({error:'Enter your name, a valid email and a password of at least 8 characters.'});
  const hash=await bcrypt.hash(password,12);
  const result=db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name.trim(),email.trim().toLowerCase(),hash);
  const user=db.prepare('SELECT id,name,email FROM users WHERE id=?').get(result.lastInsertRowid);
  const token=jwt.sign({id:user.id,email:user.email},JWT_SECRET||'development-only-secret',{expiresIn:'7d'});
  res.status(201).json({user,token});
 }catch(e){res.status(400).json({error:e.code==='SQLITE_CONSTRAINT_UNIQUE'?'An account with that email already exists.':'Could not create account.'});}
});
app.post('/api/auth/login',async(req,res)=>{
 const {email,password}=req.body||{};
 const u=db.prepare('SELECT * FROM users WHERE email=?').get(String(email||'').toLowerCase());
 if(!u||!await bcrypt.compare(password||'',u.password_hash))return res.status(401).json({error:'Email or password is incorrect.'});
 const user=safeUser(u);const token=jwt.sign({id:u.id,email:u.email},JWT_SECRET||'development-only-secret',{expiresIn:'7d'});
 res.json({user,token});
});
app.get('/api/businesses',(req,res)=>{
 const businesses=db.prepare('SELECT id,name,description,created_at FROM businesses ORDER BY id DESC LIMIT 100').all();
 res.json({businesses});
});
app.post('/api/businesses',auth,(req,res)=>{
 const {name,description}=req.body||{};
 if(!name?.trim()||!description?.trim())return res.status(400).json({error:'Business name and description are required.'});
 const result=db.prepare('INSERT INTO businesses(name,description,owner_id) VALUES(?,?,?)').run(name.trim(),description.trim(),req.user.id);
 const business=db.prepare('SELECT id,name,description,created_at FROM businesses WHERE id=?').get(result.lastInsertRowid);
 res.status(201).json({business});
});
app.post('/api/ai/chat',async(req,res)=>{
 const {message,history=[]}=req.body||{};
 if(!message?.trim())return res.status(400).json({error:'Message is required.'});
 if(!process.env.OPENAI_API_KEY)return res.json({reply:'AI is not connected yet. Add OPENAI_API_KEY to server/.env, restart the server, and try again. I can still help you navigate the M platform.'});
 try{
  const input=[...history.slice(-8).map(m=>({role:m.role==='assistant'?'assistant':'user',content:[{type:'input_text',text:String(m.content||'')}]})),{role:'user',content:[{type:'input_text',text:message}]}];
  const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4.1-mini',instructions:'You are M, a helpful assistant. Be accurate, safe and concise. Support English and Kinyarwanda when asked.',input})});
  const data=await response.json();
  if(!response.ok)return res.status(502).json({error:data.error?.message||'AI provider request failed.'});
  const reply=data.output?.flatMap(x=>x.content||[]).filter(x=>x.type==='output_text').map(x=>x.text).join('\\n')||'No response was returned.';
  res.json({reply});
 }catch(e){res.status(502).json({error:'Could not reach the AI service. Please try again.'});}
});
app.get('/api/youtube/search',async(req,res)=>{
 if(!process.env.YOUTUBE_API_KEY)return res.status(503).json({error:'YouTube API is not configured. Add YOUTUBE_API_KEY to server/.env.'});
 try{
  const url=new URL('https://www.googleapis.com/youtube/v3/search');
  url.search=new URLSearchParams({part:'snippet',q:String(req.query.q||''),type:'video',maxResults:'10',key:process.env.YOUTUBE_API_KEY});
  const r=await fetch(url);const data=await r.json();if(!r.ok)return res.status(502).json({error:data.error?.message||'YouTube search failed.'});
  res.json({items:(data.items||[]).map(v=>({id:v.id.videoId,title:v.snippet.title,channel:v.snippet.channelTitle,thumbnail:v.snippet.thumbnails?.medium?.url}))});
 }catch{return res.status(502).json({error:'Could not reach YouTube.'});}
});
app.listen(PORT,()=>console.log(`M API running on http://localhost:${PORT}`));