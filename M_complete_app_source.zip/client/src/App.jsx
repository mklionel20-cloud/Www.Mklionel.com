import React, { useEffect, useRef, useState } from 'react';
import { Bot, Music2, BriefcaseBusiness, Youtube, Globe2, LogIn, LogOut, Menu, X, Send, Play, Pause, Upload, Search, Plus, Sparkles, Headphones, Radio, UserRound, ChevronRight } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';
const words = {
  en: { tagline:'Your world. One platform.', home:'Overview', ai:'AI assistant', music:'Music studio', business:'Business hub', youtube:'YouTube', login:'Sign in', register:'Create account', logout:'Sign out', welcome:'Welcome to M', subtitle:'One place for ideas, music and business.', ask:'Ask M anything...', send:'Send', aiTitle:'Meet your AI assistant', aiDesc:'Ask questions, plan projects or get help creating something new.', musicTitle:'Your music studio', musicDesc:'Play an audio file from your device. Only upload music you have rights to use.', choose:'Choose audio file', businessTitle:'Business hub', businessDesc:'Discover and share businesses with the M community.', businessName:'Business name', businessAbout:'Short description', addBusiness:'Add business', search:'Search YouTube videos', searchHint:'Type a song, artist or topic', searchBtn:'Search', noResults:'No businesses yet. Add the first one.', email:'Email address', password:'Password', name:'Your name', haveAccount:'Already have an account?', needAccount:'Need an account?', loading:'Please wait...', aiSetup:'AI is not connected yet. Add OPENAI_API_KEY to server/.env to enable the AI assistant.' },
  rw: { tagline:'Isi yawe. Urubuga rumwe.', home:'Ahabanza', ai:'Umufasha wa AI', music:'Studio y’umuziki', business:'Ubucuruzi', youtube:'YouTube', login:'Injira', register:'Fungura konti', logout:'Sohoka', welcome:'Murakaza neza kuri M', subtitle:'Ahantu hamwe ho guhanga, umuziki n’ubucuruzi.', ask:'Baza M ikibazo...', send:'Ohereza', aiTitle:'Umufasha wawe wa AI', aiDesc:'Baza ibibazo, tegura imishinga cyangwa uhange ibishya.', musicTitle:'Studio yawe y’umuziki', musicDesc:'Curanga indirimbo iri muri telefone yawe. Koresha umuziki ufitiye uburenganzira.', choose:'Hitamo indirimbo', businessTitle:'Urubuga rw’ubucuruzi', businessDesc:'Menya kandi usangize abandi ubucuruzi.', businessName:'Izina ry’ubucuruzi', businessAbout:'Ibisobanuro bigufi', addBusiness:'Ongeraho ubucuruzi', search:'Shakisha amashusho kuri YouTube', searchHint:'Andika indirimbo, umuririmbyi cyangwa ingingo', searchBtn:'Shakisha', noResults:'Nta bucuruzi burimo. Ongeraho ubwa mbere.', email:'Imeyili', password:'Ijambo ry’ibanga', name:'Amazina yawe', haveAccount:'Usanzwe ufite konti?', needAccount:'Ukeneye konti?', loading:'Tegereza...', aiSetup:'AI ntirafungurwa. Ongeraho OPENAI_API_KEY muri server/.env kugira ngo ikore.' }
};

export default function App() {
  const [lang,setLang] = useState('en');
  const [page,setPage] = useState('home');
  const [menu,setMenu] = useState(false);
  const [token,setToken] = useState(localStorage.getItem('m_token') || '');
  const [user,setUser] = useState(JSON.parse(localStorage.getItem('m_user') || 'null'));
  const [authMode,setAuthMode] = useState('login');
  const [auth,setAuth] = useState({name:'',email:'',password:''});
  const [notice,setNotice] = useState('');
  const [chat,setChat] = useState([{role:'assistant',content:'Hi! I’m M. How can I help you today?'}]);
  const [prompt,setPrompt] = useState('');
  const [busy,setBusy] = useState(false);
  const [businesses,setBusinesses] = useState([]);
  const [biz,setBiz] = useState({name:'',description:''});
  const [query,setQuery] = useState('');
  const [audioUrl,setAudioUrl] = useState('');
  const [audioName,setAudioName] = useState('');
  const audioRef = useRef(null);
  const [playing,setPlaying] = useState(false);
  const t = words[lang];

  useEffect(()=>{ fetch(`${API}/api/businesses`).then(r=>r.json()).then(d=>setBusinesses(d.businesses||[])).catch(()=>{}); },[]);
  const headers = {'Content-Type':'application/json', ...(token?{Authorization:`Bearer ${token}`}:{})};
  async function submitAuth(e) {
    e.preventDefault(); setNotice('');
    try {
      const r=await fetch(`${API}/api/auth/${authMode}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(auth)});
      const d=await r.json(); if(!r.ok) throw new Error(d.error||'Could not sign in');
      setToken(d.token);setUser(d.user);localStorage.setItem('m_token',d.token);localStorage.setItem('m_user',JSON.stringify(d.user));setNotice('Welcome to M!');setPage('home');
    } catch(err){setNotice(err.message);}
  }
  function logout(){setToken('');setUser(null);localStorage.removeItem('m_token');localStorage.removeItem('m_user');setNotice('Signed out.');}
  async function sendChat(e) {
    e.preventDefault(); if(!prompt.trim())return;
    const question=prompt.trim();setPrompt('');setChat(c=>[...c,{role:'user',content:question}]);setBusy(true);
    try {
      const r=await fetch(`${API}/api/ai/chat`,{method:'POST',headers,body:JSON.stringify({message:question,history:chat.slice(-8)})});
      const d=await r.json(); if(!r.ok)throw new Error(d.error||'AI request failed');
      setChat(c=>[...c,{role:'assistant',content:d.reply||'I could not generate a response.'}]);
    } catch(err){setChat(c=>[...c,{role:'assistant',content:err.message}]);}
    finally{setBusy(false);}
  }
  async function addBusiness(e){
    e.preventDefault();setNotice('');
    try{
      const r=await fetch(`${API}/api/businesses`,{method:'POST',headers,body:JSON.stringify(biz)});
      const d=await r.json();if(!r.ok)throw new Error(d.error||'Please sign in first');
      setBusinesses(b=>[d.business,...b]);setBiz({name:'',description:''});setNotice('Business added.');
    }catch(err){setNotice(err.message);}
  }
  function selectAudio(e){const f=e.target.files?.[0];if(!f)return;if(audioUrl)URL.revokeObjectURL(audioUrl);setAudioUrl(URL.createObjectURL(f));setAudioName(f.name);setPlaying(false);}
  const nav=[['home',t.home,Globe2],['ai',t.ai,Bot],['music',t.music,Music2],['business',t.business,BriefcaseBusiness],['youtube',t.youtube,Youtube]];
  return <div className="app-shell">
    <header className="topbar"><button className="brand" onClick={()=>setPage('home')}><span className="brand-mark">M</span><span>M<span className="brand-dot">.</span></span></button>
      <nav className="desktop-nav">{nav.map(([id,label,Icon])=><button key={id} className={page===id?'active':''} onClick={()=>setPage(id)}><Icon size={16}/>{label}</button>)}</nav>
      <div className="top-actions"><button className="lang" onClick={()=>setLang(lang==='en'?'rw':'en')}><Globe2 size={15}/>{lang==='en'?'EN':'RW'}</button>{user?<button className="user-pill" onClick={logout}><UserRound size={16}/>{user.name?.split(' ')[0]||'Account'}<LogOut size={15}/></button>:<button className="sign-btn" onClick={()=>{setPage('auth');setAuthMode('login')}}><LogIn size={16}/>{t.login}</button>}<button className="mobile-menu" onClick={()=>setMenu(!menu)}>{menu?<X/>:<Menu/>}</button></div>
    </header>
    {menu&&<div className="mobile-nav">{nav.map(([id,label,Icon])=><button key={id} onClick={()=>{setPage(id);setMenu(false)}}><Icon size={17}/>{label}</button>)}</div>}
    <main>
      {notice&&<div className="notice" onClick={()=>setNotice('')}>{notice}<button>×</button></div>}
      {page==='home'&&<><section className="hero"><div className="hero-copy"><div className="eyebrow"><Sparkles size={14}/> AI · MUSIC · BUSINESS</div><h1>{t.welcome}<br/><span>Everything connects.</span></h1><p>{t.subtitle} {t.tagline}</p><div className="hero-buttons"><button className="primary" onClick={()=>setPage('ai')}>Explore M <ChevronRight size={17}/></button><button className="secondary" onClick={()=>setPage('music')}><Play size={16}/> Open music</button></div><div className="trust-line"><span className="live-dot"></span> A smarter way to create and connect</div></div><div className="hero-art"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="orb-core"><span>M</span></div><div className="float-card card-ai"><Bot size={18}/><span>AI assistant</span><b>Ready to help</b></div><div className="float-card card-music"><Music2 size={18}/><span>Music studio</span><b>Your sound</b></div><div className="float-card card-business"><BriefcaseBusiness size={18}/><span>Business hub</span><b>Grow together</b></div></div></section>
      <section className="feature-grid">{[['ai',Bot,'AI assistant','Ideas, answers and creative support.'],['music',Headphones,'Music studio','Play your own tracks in one place.'],['business',BriefcaseBusiness,'Business hub','Share your business with the community.'],['youtube',Youtube,'YouTube discovery','Find videos and music on YouTube.']].map(([id,Icon,title,desc])=><button className="feature-card" key={id} onClick={()=>setPage(id)}><span className="feature-icon"><Icon size={21}/></span><b>{title}</b><p>{desc}</p><ChevronRight className="feature-arrow" size={17}/></button>)}</section></>}
      {page==='ai'&&<section className="workspace"><div className="section-heading"><div className="eyebrow"><Sparkles size={14}/> M INTELLIGENCE</div><h2>{t.aiTitle}</h2><p>{t.aiDesc}</p></div><div className="chat-panel"><div className="chat-top"><span className="ai-avatar"><Bot/></span><div><b>M Assistant</b><small><i className="live-dot"></i> Online interface</small></div></div><div className="messages">{chat.map((m,i)=><div key={i} className={`message ${m.role}`}><span>{m.role==='assistant'?'M':'You'}</span><p>{m.content}</p></div>)}{busy&&<div className="message assistant"><span>M</span><p>Thinking...</p></div>}</div><form className="chat-form" onSubmit={sendChat}><input value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder={t.ask}/><button className="primary" disabled={busy||!prompt.trim()}><Send size={17}/>{t.send}</button></form></div></section>}
      {page==='music'&&<section className="workspace"><div className="section-heading"><div className="eyebrow"><Music2 size={14}/> YOUR SOUND SPACE</div><h2>{t.musicTitle}</h2><p>{t.musicDesc}</p></div><div className="music-panel"><div className="record-art"><div className="record"><div className="record-label"><Music2 size={34}/></div></div></div><div className="track-info"><span className="eyebrow">LOCAL AUDIO PLAYER</span><h3>{audioName||'Your next favorite track'}</h3><p>{audioName?'Selected from your device':'Choose an audio file to start listening.'}</p><div className="music-controls"><label className="primary upload-btn"><Upload size={17}/>{t.choose}<input type="file" accept="audio/*" onChange={selectAudio}/></label><button className="play-btn" disabled={!audioUrl} onClick={()=>{if(playing)audioRef.current.pause();else audioRef.current.play();setPlaying(!playing)}}>{playing?<Pause/>:<Play/>}</button></div>{audioUrl&&<audio ref={audioRef} src={audioUrl} controls onEnded={()=>setPlaying(false)} className="audio-control"/>}</div></div></section>}
      {page==='business'&&<section className="workspace"><div className="section-heading"><div className="eyebrow"><BriefcaseBusiness size={14}/> CONNECT & GROW</div><h2>{t.businessTitle}</h2><p>{t.businessDesc}</p></div><form className="business-form" onSubmit={addBusiness}><input required placeholder={t.businessName} value={biz.name} onChange={e=>setBiz({...biz,name:e.target.value})}/><input required placeholder={t.businessAbout} value={biz.description} onChange={e=>setBiz({...biz,description:e.target.value})}/><button className="primary"><Plus size={17}/>{t.addBusiness}</button></form><div className="business-grid">{businesses.length?businesses.map(b=><article className="business-card" key={b.id}><span className="feature-icon"><BriefcaseBusiness/></span><h3>{b.name}</h3><p>{b.description}</p><small>Shared on M</small></article>):<p className="empty">{t.noResults}</p>}</div></section>}
      {page==='youtube'&&<section className="workspace"><div className="section-heading"><div className="eyebrow"><Youtube size={14}/> VIDEO DISCOVERY</div><h2>YouTube, connected.</h2><p>Search YouTube and open results on YouTube. This starter does not host or copy copyrighted videos.</p></div><form className="youtube-search" onSubmit={e=>{e.preventDefault();if(query.trim())window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`,'_blank','noopener,noreferrer')}}><Search/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={t.searchHint}/><button className="primary">{t.searchBtn}</button></form><div className="youtube-note"><Youtube size={32}/><b>Discover what you love</b><span>Search music, tutorials, entertainment and more.</span></div></section>}
      {page==='auth'&&<section className="auth-wrap"><form className="auth-card" onSubmit={submitAuth}><span className="brand-mark large">M</span><h2>{authMode==='login'?t.login:t.register}</h2><p>Join the M community.</p>{authMode==='register'&&<input required placeholder={t.name} value={auth.name} onChange={e=>setAuth({...auth,name:e.target.value})}/>}<input required type="email" placeholder={t.email} value={auth.email} onChange={e=>setAuth({...auth,email:e.target.value})}/><input required type="password" minLength="8" placeholder={t.password} value={auth.password} onChange={e=>setAuth({...auth,password:e.target.value})}/><button className="primary full" disabled={busy}>{t.loading==='Please wait...'?(authMode==='login'?t.login:t.register):(authMode==='login'?t.login:t.register)}</button><button type="button" className="text-btn" onClick={()=>setAuthMode(authMode==='login'?'register':'login')}>{authMode==='login'?t.needAccount:t.haveAccount}</button></form></section>}
    </main>
    <footer><div className="footer-brand"><span className="brand-mark">M</span><b>M Platform</b></div><span>AI · Music · Business</span><span>© 2026 M. Built to connect ideas.</span></footer>
  </div>;
}