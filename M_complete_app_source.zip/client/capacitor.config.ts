import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.m.platform',
  appName: 'M',
  webDir: 'dist',
  server: { androidScheme: 'https' }
};
export default config;